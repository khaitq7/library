/*

Copyright 2015 Akexorcist

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

*/

package com.akexorcist.roundcornerprogressbar;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.akexorcist.roundcornerprogressbar.common.BaseRoundCornerProgressBar;


/**
 * Created by Akexorcist on 9/14/15 AD.
 */
public class RoundCornerProgressBar extends BaseRoundCornerProgressBar {

    public RoundCornerProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RoundCornerProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public int initLayout() {
        return R.layout.layout_round_corner_progress_bar;
    }

    @Override
    protected void initStyleable(Context context, AttributeSet attrs) {

    }

    @Override
    protected void initView() {

    }

    @SuppressWarnings("deprecation")
    @Override
    protected void drawProgress(LinearLayout layoutProgress, float max, float progress, float totalWidth,
                                int radius, int padding, int colorProgress, boolean isReverse) {
        GradientDrawable backgroundDrawable = createGradientDrawable(colorProgress);
        int newRadius = radius - (padding / 2);
        backgroundDrawable.setCornerRadii(new float[]{newRadius, newRadius, newRadius, newRadius, newRadius, newRadius, newRadius, newRadius});
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            layoutProgress.setBackground(backgroundDrawable);
        } else {
            layoutProgress.setBackgroundDrawable(backgroundDrawable);
        }

        float ratio = max / progress;
        int progressWidth = (int) ((totalWidth - (padding * 2)) / ratio);
        ViewGroup.LayoutParams progressParams = layoutProgress.getLayoutParams();
        progressParams.width = progressWidth;
        layoutProgress.setLayoutParams(progressParams);
    }

    @Override
    protected void onViewDraw() {

    }

    boolean touchOn;
    boolean mDownTouch = false;
    private float x1,x2;
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        super.onTouchEvent(event);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = event.getX();
                Log.e("Touching","Down");
                touchOn = !touchOn;
                invalidate();

                mDownTouch = true;
                return true;

            case MotionEvent.ACTION_MOVE:
                x2 = event.getX();
                if (x1 < x2) {
                    Log.e("Moving",x1 + "-" + x2 + ": Left to Right Swap Performed");

                }
                // if right to left sweep event on screen
                if (x1 > x2) {
                    Log.e("Moving",x1 + "-" + x2 + ": Right to Left Swap Performed");
                    //   setProgress(getProgress() - 1);
                }
                float a =  (int) (this.getMax() * event.getX() / this.getWidth());
                Log.e("Done",String.valueOf(a));
                setProgress(a);
                if(getProgress() <= 3) {
                    this.setProgressColor(getResources().getColor(R.color.custom_progress_red_progress));
                } else if(getProgress() > 3 && getProgress() <= 6) {
                    this.setProgressColor(getResources().getColor(R.color.custom_progress_orange_progress));
                } else if(getProgress() > 6) {
                    this.setProgressColor(getResources().getColor(R.color.custom_progress_green_progress));
                }
                return true;

            case MotionEvent.ACTION_UP:
                x2 = event.getX();
                if (x1 < x2) {
                    Log.e("Up",x1 + "-" + x2 + ": Left to Right Swap Performed");
                }
                // if right to left sweep event on screen
                if (x1 > x2) {
                    Log.e("Up",x1 + "-" + x2 + ": Right to Left Swap Performed");
                }
                if (mDownTouch) {
                    mDownTouch = false;
                    performClick(); // Call this method to handle the response, and
                    // thereby enable accessibility services to
                    // perform this action for a user who cannot
                    // click the touchscreen.
                    return true;
                }
        }
        return false; // Return false for other touch events
    }

    @Override
    public boolean performClick() {
        // Calls the super implementation, which generates an AccessibilityEvent
        // and calls the onClick() listener on the view, if any
        super.performClick();

        // Handle the action for the custom click here
        return true;
    }

}
